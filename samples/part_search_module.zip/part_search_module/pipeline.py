"""
Core pipeline logic for the Part Search Istari module.
All logic is here; part_search_handler.py is the thin entry-point adapter.
"""

from __future__ import annotations

import json
import logging
import warnings
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, field_validator, model_validator
from pydantic_ai import Agent
from istari_digital_client import Client, Configuration, V3Client
from istari_digital_client.v3.models.new_revision_relationship_dto import NewRevisionRelationshipDto
from istari_digital_client.v3.models.resource_type_dto import ResourceTypeDto

warnings.filterwarnings("ignore")
logging.disable(logging.CRITICAL)

PROVIDER_DEFAULTS = {
    "anthropic": "claude-opus-4-5",
    "openai":    "gpt-4o",
    "genesis":   "gpt-4o",
}

GENESIS_BASE_URL = "https://api.ai.us.lmco.com/v1"

SCHEMA_FILES = {
    "nexar":         "part-search-spec.schema.json",
    "siliconexpert": "se-part-search-spec.schema.json",
}

# Schema files are expected alongside this file (copied into the module package)
HERE = Path(__file__).parent

BATCH_SIZE = 20


# ════════════════════════════════════════════════════════════════════════════
# Pydantic models
# ════════════════════════════════════════════════════════════════════════════

class RawRequirement(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id:     str
    name:   str = ""
    text:   str = ""
    req_id: str = ""

    @model_validator(mode="before")
    @classmethod
    def _extract_from_cameo(cls, data: dict) -> dict:
        tags = data.get("tags", {})
        if not data.get("text"):
            data["text"] = tags.get("Text", "")
        if not data.get("req_id"):
            data["req_id"] = tags.get("Id", "")
        return data

    def is_actionable(self) -> bool:
        return bool(self.text and self.text.strip())


class HardwareReq(BaseModel):
    id:       str
    text:     str
    category: Literal["structural", "mechanical", "electrical", "thermal", "fastener", "other"]


class MaterialReq(BaseModel):
    id:          str
    text:        str
    spec_number: str | None = None


class PerformanceReq(BaseModel):
    id:    str
    text:  str
    value: float | None = None
    unit:  str | None = None


class ExtractedRequirements(BaseModel):
    hardware:    list[HardwareReq]
    material:    list[MaterialReq]
    performance: list[PerformanceReq]
    skipped_ids: list[str]


# ── Nexar / Octopart models ───────────────────────────────────────────────────

OutputGroup = Literal["basic", "specs", "offers", "datasheet", "lifecycle", "cad", "compliance"]


class SearchSpec(BaseModel):
    category_id:      str = Field(description="Octopart/Nexar numeric category ID — required")
    q:                str | None = None
    category:         str | None = None
    distributors:     list[str] | None = Field(default=None, min_length=1)
    limit:            int | None = Field(default=None, ge=1, le=100)
    start:            int | None = Field(default=None, ge=0)
    manufacturers:    list[str] | None = Field(default=None, min_length=1)
    in_stock:         bool | None = None
    has_datasheet:    bool | None = None
    lifecycle_status: list[Literal["Active","NRND","Obsolete","Discontinued","Unknown"]] | None = Field(default=None, min_length=1)
    sort:             str | None = None
    sort_direction:   Literal["asc", "desc"] | None = None

    @field_validator("category_id")
    @classmethod
    def _category_id_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("category_id must not be empty")
        return v


class OutputSpec(BaseModel):
    groups: list[OutputGroup] | None = None


class PartSearchSpec(BaseModel):
    search:     SearchSpec
    parameters: dict[str, str] = Field(default_factory=dict)
    output:     OutputSpec | None = None

    @field_validator("parameters")
    @classmethod
    def _all_values_are_strings(cls, v: dict) -> dict:
        for key, val in v.items():
            if not isinstance(val, str):
                raise ValueError(f"parameters['{key}'] must be a string, got {type(val).__name__}")
        return v


class PartSearchResult(BaseModel):
    source_req_id: str
    priority:      Literal["critical", "high", "medium", "low"] = "medium"
    part_search:   PartSearchSpec


# ── SiliconExpert models ──────────────────────────────────────────────────────

class SEFilter(BaseModel):
    name:  str
    value: str


class SEPartSearchSpec(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    category:      str = Field(description="SiliconExpert taxonomy category name — required")
    keyword:       str | None = None
    manufacturer:  str | None = None
    filters:       list[SEFilter] = Field(min_length=1)
    lifecycle:     list[Literal["Active","NRND","EOL","Obsolete","Unknown"]] | None = Field(default=None, min_length=1)
    rohsCompliant:  bool | None = None
    reachCompliant: bool | None = None
    pageSize:       int | None = Field(default=None, ge=1, le=100)
    pageNumber:     int | None = Field(default=None, ge=1)
    fields:         list[Literal["lifecycle","compliance","parametrics","pricing","alternates","pcn","environmental"]] | None = None

    @field_validator("category")
    @classmethod
    def _category_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("category must not be empty")
        return v


class SEPartSearchResult(BaseModel):
    source_req_id: str
    priority:      Literal["critical", "high", "medium", "low"] = "medium"
    part_search:   SEPartSearchSpec


# ════════════════════════════════════════════════════════════════════════════
# IstariCapability
# ════════════════════════════════════════════════════════════════════════════

class IstariCapability(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    registry_url: str
    pat:          str = Field(repr=False)

    _v3: V3Client = PrivateAttr()
    _v2: Client   = PrivateAttr()

    @field_validator("registry_url")
    @classmethod
    def _strip_slash(cls, v: str) -> str:
        return v.rstrip("/")

    @field_validator("pat")
    @classmethod
    def _pat_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Istari PAT must not be empty")
        return v

    def model_post_init(self, __context: object) -> None:
        config = Configuration(registry_url=self.registry_url, registry_auth_token=self.pat)
        self._v3 = V3Client(config)
        self._v2 = Client(config)

    def fetch_requirements_from_path(self, path: Path) -> list[RawRequirement]:
        """Load requirements directly from a local file path (module input file)."""
        raw = json.loads(path.read_text())
        if not isinstance(raw, list):
            raw = [raw]
        return [RawRequirement.model_validate(r) for r in raw if isinstance(r, dict)]

    def get_revision_id(self, resource_id: str) -> str:
        return self._v3.get_resource(resource_id).file_revision_id

    def get_resource_name(self, resource_id: str) -> str | None:
        try:
            return self._v3.get_resource(resource_id).display_name
        except Exception:
            return None

    def upload_resource(self, path: Path, display_name: str, description: str):
        return self._v3.create_resource(
            path=path,
            resource_type=ResourceTypeDto.MODEL,
            display_name=display_name,
            description=description,
            version_name="v1.0",
            external_identifier=f"part-search-module/{display_name}",
        )

    def _get_produces_type_id(self) -> str:
        try:
            page = self._v3.list_revision_relationship_types(size=100)
            for rt in (page.items or []):
                name = (getattr(rt, "name", "") or "").lower()
                if name in ("produces", "produce"):
                    return rt.id
            names = [getattr(rt, "name", "?") for rt in (page.items or [])]
            print(f"  [link] WARNING: 'produces' not found. Available: {names}")
        except Exception as exc:
            print(f"  [link] WARNING: could not list relationship types: {exc}")
        fallback = "fea9bd01-81bc-4db4-9aff-289bdd9745c4"
        print(f"  [link] using fallback type id: {fallback}")
        return fallback

    def link_resources(self, from_revision_id: str, to_revision_id: str) -> None:
        type_id = self._get_produces_type_id()
        self._v3.create_revision_relationship(
            NewRevisionRelationshipDto(
                relationship_type_id=type_id,
                left_revision_id=from_revision_id,
                right_revision_id=to_revision_id,
            )
        )


# ════════════════════════════════════════════════════════════════════════════
# Schema loader
# ════════════════════════════════════════════════════════════════════════════

def load_schema(search_api: str = "nexar") -> str:
    fname = SCHEMA_FILES.get(search_api)
    if not fname:
        raise ValueError(f"Unknown search_api '{search_api}'.")
    path = HERE / fname
    if not path.exists():
        raise FileNotFoundError(f"Schema file not found: {path}")
    return json.dumps(json.loads(path.read_text()), indent=2)


# ════════════════════════════════════════════════════════════════════════════
# Agent system prompts
# ════════════════════════════════════════════════════════════════════════════

EXTRACT_SYSTEM = """\
You are a systems engineering analyst specialising in hardware BOM generation.

Given a list of raw Cameo/SysML requirements, classify each into:
- hardware: requirements describing a physical part, component, or assembly
- material: requirements referencing a material spec (AMS, MIL-SPEC, ASTM, etc.)
- performance: requirements with measurable values and units
- skipped_ids: IDs that are functional/behavioural/geometric design constraints
  on custom-manufactured parts — not commercially procurable

Rules:
- Only skip if a requirement clearly cannot drive a part search.
- Preserve original requirement IDs exactly."""


def build_transform_prompt(schema_text: str, search_api: str = "nexar") -> str:
    if search_api == "siliconexpert":
        return f"""You are a procurement engineer converting engineering requirements into
structured part-search specs for the SiliconExpert ProductAPI.

OUTPUT SCHEMA
-------------
Every part_search you produce must conform to this JSON Schema:

{schema_text}

KEY RULES
---------
- part_search.category is REQUIRED. Use exact SiliconExpert taxonomy strings.
- part_search.filters: REQUIRED, min 1 entry. A list of {{name, value}} objects.
  Use SiliconExpert attribute names exactly (title-case, spaces):
    "Resistance", "Capacitance", "Inductance", "Tolerance", "Voltage Rating",
    "Current Rating", "Power Rating", "Case/Package", "Temperature Coefficient",
    "Dielectric", "Mounting Style", "Frequency".
  All values must be strings with units where applicable.
- part_search.lifecycle: ["Active"] by default.
- part_search.rohsCompliant: true for all electronic components by default.
- part_search.pageSize: 10 by default.
- part_search.fields: ["lifecycle", "compliance", "parametrics"] always.
- source_req_id: preserve exactly.
- priority: default "medium"; safety-critical → "critical"."""

    return f"""You are a procurement engineer converting engineering requirements into
structured part-search specs conforming to the Nexar/Octopart part-search-spec schema.

OUTPUT SCHEMA
-------------
Every part_search you produce must conform to this JSON Schema:

{schema_text}

KEY RULES
---------
- part_search.search.category_id is REQUIRED. Nexar/Octopart numeric IDs:
    Chip Resistors (SMD): 140    Through-hole Resistors: 3
    Ceramic Capacitors:   456    Electrolytic Capacitors: 58
    Inductors / Chokes:   57     MOSFETs:                 77
    Diodes / Rectifiers:  68     Op-Amps:                 12
    Microcontrollers:     2      Connectors (generic):    21
    USB Connectors:       298    LEDs (SMD):              85
    Crystals/Oscillators: 30     Fuses:                   172

- part_search.parameters: REQUIRED, min 1 entry. All values must be strings.
- lifecycle_status: ["Active"] by default.
- has_datasheet: true for electronic components.
- limit: 10 by default.
- output.groups: ["basic","specs","offers","datasheet","lifecycle"] always.
- source_req_id: preserve exactly.
- priority: default "medium"; safety-critical → "critical"."""


# ════════════════════════════════════════════════════════════════════════════
# Agent factory
# ════════════════════════════════════════════════════════════════════════════

def _make_openai_llm(model_name: str, api_key: str, base_url: str | None = None):
    try:
        from pydantic_ai.models.openai import OpenAIModel as _Model
    except ImportError:
        from pydantic_ai.models.openai import OpenAIChatModel as _Model  # type: ignore[no-redef]
    from pydantic_ai.providers.openai import OpenAIProvider as _Provider
    kwargs: dict = {"api_key": api_key}
    if base_url:
        kwargs["base_url"] = base_url
    return _Model(model_name, provider=_Provider(**kwargs))


def build_agents(
    provider: str,
    api_key: str,
    model_name: str,
    schema_text: str,
    search_api: str = "nexar",
) -> tuple[Agent, Agent]:
    if provider == "anthropic":
        try:
            from pydantic_ai.models.anthropic import AnthropicModel as _Model
        except ImportError:
            from pydantic_ai.models.anthropic import AnthropicChatModel as _Model  # type: ignore[no-redef]
        try:
            from pydantic_ai.providers.anthropic import AnthropicProvider as _Provider
        except ImportError:
            from pydantic_ai.providers.anthropic import AnthropicChatProvider as _Provider  # type: ignore[no-redef]
        llm = _Model(model_name, provider=_Provider(api_key=api_key))

    elif provider == "openai":
        llm = _make_openai_llm(model_name, api_key)

    elif provider == "genesis":
        llm = _make_openai_llm(model_name, api_key, base_url=GENESIS_BASE_URL)

    else:
        raise ValueError(f"Unknown provider '{provider}'. Choose 'anthropic', 'openai', or 'genesis'.")

    transform_output_type = (
        list[SEPartSearchResult] if search_api == "siliconexpert" else list[PartSearchResult]
    )

    extract_agent: Agent = Agent(
        llm,
        output_type=ExtractedRequirements,
        system_prompt=EXTRACT_SYSTEM,
    )
    transform_agent: Agent = Agent(
        llm,
        output_type=transform_output_type,
        system_prompt=build_transform_prompt(schema_text, search_api),
    )
    return extract_agent, transform_agent


# ════════════════════════════════════════════════════════════════════════════
# Pipeline
# ════════════════════════════════════════════════════════════════════════════

def run_pipeline(
    requirements_path: Path,
    output_dir: Path,
    istari: IstariCapability | None,
    extract_agent: Agent,
    transform_agent: Agent,
    search_api: str = "nexar",
    req_revision_id: str | None = None,
) -> dict:
    """
    Run the full pipeline.

    Args:
        requirements_path: Local path to requirements.json (already downloaded by agent).
        output_dir:        Directory to write output files into.
        istari:            IstariCapability for linking outputs (can be None in standalone mode).
        extract_agent:     pydantic-ai extract agent.
        transform_agent:   pydantic-ai transform agent.
        search_api:        'nexar' or 'siliconexpert'.
        req_revision_id:   Revision ID for the requirements resource (for linking).

    Returns:
        dict with keys: summary, output_files (list of {name, type, value} for output.json)
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # Step 1: Load requirements
    print(f"[1/3] Loading requirements from {requirements_path} ...")
    if istari:
        all_reqs = istari.fetch_requirements_from_path(requirements_path)
    else:
        raw = json.loads(requirements_path.read_text())
        if not isinstance(raw, list):
            raw = [raw]
        all_reqs = [RawRequirement.model_validate(r) for r in raw if isinstance(r, dict)]

    actionable = [r for r in all_reqs if r.is_actionable()]
    print(f"      {len(all_reqs)} total, {len(actionable)} with text")

    if not actionable:
        print("No actionable requirements.")
        summary = {"total_requirements": 0, "classified": 0, "specs_generated": 0, "outputs": []}
        summary_path = output_dir / "part_search_summary.json"
        summary_path.write_text(json.dumps(summary, indent=2))
        return {"summary": summary, "output_files": [
            {"name": "summary", "type": "file", "value": str(summary_path)},
        ]}

    # Step 2: Classify
    print(f"[2/3] Classifying requirements ...")
    req_text = "\n".join(f"[{r.req_id or r.id}] {r.text}" for r in actionable)
    extracted: ExtractedRequirements = extract_agent.run_sync(
        f"Classify these requirements:\n\n{req_text}"
    ).output

    print(f"      hardware={len(extracted.hardware)}  "
          f"material={len(extracted.material)}  "
          f"performance={len(extracted.performance)}  "
          f"skipped={len(extracted.skipped_ids)}")

    all_typed = (
        [f"[HW:{r.id}]   {r.text}" for r in extracted.hardware] +
        [f"[MAT:{r.id}]  {r.text}  spec={r.spec_number or 'N/A'}" for r in extracted.material] +
        [f"[PERF:{r.id}] {r.text}  value={r.value}{r.unit or ''}" for r in extracted.performance]
    )

    if not all_typed:
        print("All requirements skipped.")
        summary = {
            "total_requirements": len(actionable),
            "classified": 0,
            "skipped_ids": extracted.skipped_ids,
            "specs_generated": 0,
            "outputs": [],
        }
        summary_path = output_dir / "part_search_summary.json"
        summary_path.write_text(json.dumps(summary, indent=2))
        return {"summary": summary, "output_files": [
            {"name": "summary", "type": "file", "value": str(summary_path)},
        ]}

    # Step 3: Transform
    api_label = "SiliconExpert" if search_api == "siliconexpert" else "Nexar/Octopart"
    print(f"[3/3] Transforming to {api_label} specs ...")

    results: list = []
    batches = [all_typed[i:i+BATCH_SIZE] for i in range(0, len(all_typed), BATCH_SIZE)]
    for i, batch in enumerate(batches, 1):
        print(f"      Batch {i}/{len(batches)} ({len(batch)} requirements) ...")
        results.extend(
            transform_agent.run_sync(
                "Convert each requirement to a PartSearchResult:\n\n" + "\n".join(batch)
            ).output
        )

    print(f"      {len(results)} specs generated")

    # Write results directory
    results_dir = output_dir / "part_search_results"
    results_dir.mkdir(exist_ok=True)

    file_suffix = "_se_part_search.json" if search_api == "siliconexpert" else "_part_search.json"
    schema_ref = (
        "./se-part-search-spec.schema.json"
        if search_api == "siliconexpert"
        else "./part-search-spec.schema.json"
    )

    output_records = []
    for r in results:
        spec_data = {"$schema": schema_ref, **r.part_search.model_dump(exclude_none=True)}
        fname = f"{r.source_req_id}{file_suffix}"
        fpath = results_dir / fname
        fpath.write_text(json.dumps(spec_data, indent=2))
        output_records.append({"req_id": r.source_req_id, "file": fname})

        # Link to requirements revision in Istari if available
        if istari and req_revision_id:
            try:
                resource = istari.upload_resource(
                    fpath, fname,
                    f"Part search spec [{r.source_req_id}] — part search module",
                )
                istari.link_resources(req_revision_id, resource.file_revision_id)
                print(f"  ✓ {fname} linked in Istari")
            except Exception as exc:
                print(f"  [warn] Could not upload/link {fname}: {exc}")

    summary = {
        "search_api":         search_api,
        "total_requirements": len(actionable),
        "classified":         len(all_typed),
        "skipped_ids":        extracted.skipped_ids,
        "specs_generated":    len(results),
        "outputs":            output_records,
    }
    summary_path = output_dir / "part_search_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2))

    return {
        "summary": summary,
        "output_files": [
            {"name": "part_search_results", "type": "directory", "value": str(results_dir)},
            {"name": "summary",             "type": "file",      "value": str(summary_path)},
        ],
    }
