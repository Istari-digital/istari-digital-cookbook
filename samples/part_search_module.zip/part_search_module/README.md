# Part Search Agent — Istari Module

Istari module that reads a `requirements.json` artifact extracted from a Cameo/SysML
model, uses an LLM to classify and transform requirements into structured part-search
specs, and uploads results back to Istari as artifacts.

Two function variants are declared in the manifest:

| Function key            | Output format              |
|-------------------------|---------------------------|
| `@local:part_search`    | Nexar / Octopart JSON     |
| `@local:part_search_se` | SiliconExpert ProductAPI JSON |

---

## Directory structure

```
part_search_module/
├── module_manifest.json          # Istari module contract — publish this
├── part_search_handler.py        # Entry point called by the agent
├── pipeline.py                   # Core LLM pipeline logic
├── part-search-spec.schema.json  # Nexar output schema (copy from parent dir)
├── se-part-search-spec.schema.json  # SE output schema (copy from parent dir)
├── requirements.txt              # Python runtime deps
├── build.sh                      # PyInstaller build script
├── test_files/
│   ├── input.json                # Sample agent input file
│   ├── output.json               # Sample agent output file
│   └── llm_api_key.dat           # Template for auth secret file
└── README.md
```

---

## Local development / testing

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Copy schema files into this directory

```bash
cp ../part-search-spec.schema.json .
cp ../se-part-search-spec.schema.json .
```

### 3. Set environment variables

```bash
export ANTHROPIC_API_KEY=sk-ant-...
export ISTARI_REGISTRY_URL=https://your-instance.istari.app   # optional, enables Istari linking
export ISTARI_REGISTRY_AUTH_TOKEN=your-pat                    # optional
```

### 4. Run directly (simulating what the agent does)

Update `test_files/input.json` with real paths, then:

```bash
python part_search_handler.py \
  --input-file  test_files/input.json \
  --output-file /tmp/output.json \
  --temp-dir    /tmp/part_search_test
```

### 5. Inspect outputs

```bash
cat /tmp/output.json                               # output file locations
ls  /tmp/part_search_test/out/part_search_results/ # one JSON per requirement
cat /tmp/part_search_test/out/part_search_summary.json
```

---

## Publishing to Istari

### 1. Validate the manifest

```bash
stari module lint module_manifest.json
```

### 2. Build a self-contained binary (for production)

```bash
bash build.sh
```

Update `module_manifest.json`:
- `entrypoint` → `dist/part_search_handler`
- `run_command` → `{entrypoint} --input-file {input_file} --output-file {output_file} --temp-dir {temp_dir}`
- `module_checksum` → output of `sha256sum dist/part_search_handler`

### 3. Package the module

```bash
zip -r part_search_module_v1.0.0.zip \
  module_manifest.json \
  dist/part_search_handler \
  part-search-spec.schema.json \
  se-part-search-spec.schema.json
```

### 4. Publish

```bash
stari client init <REGISTRY_URL> <REGISTRY_API_KEY>
stari client publish module_manifest.json
```

### 5. Install on the agent

```bash
stari module install @local:part_search --repository <your-repo>
```

---

## LLM API key — auth secret

The LLM API key is passed as an `auth_info` input — an encrypted file the agent
decrypts at runtime. The file must be JSON:

```json
{"api_key": "sk-ant-..."}
```

Register it on the platform with:

```bash
stari client add-auth-secret --type api_key --file llm_api_key.dat
```

If no auth secret is provided, the handler falls back to the environment variable
(`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, or `GENESIS_API_KEY`).

---

## Input parameters

| Parameter    | Type       | Required | Default         | Values                          |
|--------------|------------|----------|-----------------|---------------------------------|
| requirements | user_model | Yes      | —               | requirements.json artifact      |
| provider     | parameter  | No       | `anthropic`     | anthropic \| openai \| genesis  |
| search_api   | parameter  | No       | `nexar`         | nexar \| siliconexpert          |
| model        | parameter  | No       | provider default | e.g. claude-opus-4-5, gpt-4o  |
| llm_api_key  | auth_info  | No       | env var fallback | `{"api_key": "sk-..."}` file   |

## Outputs

| Output               | Type      | Description                              |
|----------------------|-----------|------------------------------------------|
| part_search_results  | directory | One JSON spec file per requirement       |
| summary              | file      | Run summary with stats and file list     |
