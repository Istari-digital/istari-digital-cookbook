"""
Istari Module Entry Point — Part Search Agent
=============================================
The Istari Agent calls this script as:

    python part_search_handler.py
        --input-file  <path/to/input.json>
        --output-file <path/to/output.json>
        --temp-dir    <path/to/temp/>

Input file format (written by the Istari Agent):
    {
      "requirements": {"type": "user_model",  "value": "/tmp/.../requirements.json"},
      "provider":     {"type": "parameter",   "value": "anthropic"},
      "search_api":   {"type": "parameter",   "value": "nexar"},
      "model":        {"type": "parameter",   "value": "claude-opus-4-5"},
      "llm_api_key":  {"type": "auth_info",   "value": "/tmp/.../llm_api_key.dat"}
    }

Output file format (read back by the Istari Agent):
    [
      {"name": "part_search_results", "type": "directory", "value": "/tmp/.../out/part_search_results"},
      {"name": "summary",             "type": "file",      "value": "/tmp/.../out/part_search_summary.json"}
    ]

Credentials priority:
  1. llm_api_key auth_info file ({"api_key": "sk-..."})
  2. ANTHROPIC_API_KEY / OPENAI_API_KEY / GENESIS_API_KEY env var
  3. ISTARI_REGISTRY_URL / ISTARI_REGISTRY_AUTH_TOKEN env var (for Istari linking)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

# ── Local imports ─────────────────────────────────────────────────────────────
# pipeline.py must be in the same directory as this handler.
sys.path.insert(0, str(Path(__file__).parent))
from pipeline import (
    PROVIDER_DEFAULTS,
    IstariCapability,
    build_agents,
    load_schema,
    run_pipeline,
)


# ════════════════════════════════════════════════════════════════════════════
# Input file parsing
# ════════════════════════════════════════════════════════════════════════════

def _read_input(input_file: str) -> dict:
    """Parse the Istari module input.json and return a normalised dict."""
    raw = json.loads(Path(input_file).read_text())
    return {key: entry.get("value") for key, entry in raw.items()}


def _resolve_api_key(inputs: dict, provider: str) -> str | None:
    """
    Resolve the LLM API key:
    1. auth_info file ({"api_key": "..."} or {"key": "..."} or plain string)
    2. Environment variable for the provider
    """
    auth_path = inputs.get("llm_api_key")
    if auth_path and Path(auth_path).exists():
        content = Path(auth_path).read_text().strip()
        try:
            data = json.loads(content)
            key = data.get("api_key") or data.get("key") or data.get("token")
            if key:
                return key
        except json.JSONDecodeError:
            # Plain-text key file
            if content:
                return content

    env_map = {
        "anthropic": "ANTHROPIC_API_KEY",
        "openai":    "OPENAI_API_KEY",
        "genesis":   "GENESIS_API_KEY",
    }
    return os.environ.get(env_map.get(provider, ""))


def _build_istari_capability() -> IstariCapability | None:
    """Build IstariCapability from environment variables (for optional Istari linking)."""
    url   = os.environ.get("ISTARI_REGISTRY_URL")
    token = os.environ.get("ISTARI_REGISTRY_AUTH_TOKEN")
    if url and token:
        try:
            return IstariCapability(registry_url=url, pat=token)
        except Exception as exc:
            print(f"  [warn] Could not init IstariCapability: {exc}", file=sys.stderr)
    return None


# ════════════════════════════════════════════════════════════════════════════
# CLI
# ════════════════════════════════════════════════════════════════════════════

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Istari Part Search Module — file-based agent entry point",
    )
    p.add_argument("--input-file",  required=True, help="Path to Istari module input JSON")
    p.add_argument("--output-file", required=True, help="Path to write Istari module output JSON")
    p.add_argument("--temp-dir",    default=None,  help="Temp working directory provided by agent")
    return p.parse_args()


# ════════════════════════════════════════════════════════════════════════════
# Main
# ════════════════════════════════════════════════════════════════════════════

def main() -> None:
    args = parse_args()

    # ── Parse inputs ─────────────────────────────────────────────────────────
    inputs = _read_input(args.input_file)

    requirements_path = Path(inputs.get("requirements", ""))
    if not requirements_path.exists():
        print(f"ERROR: requirements file not found: {requirements_path}", file=sys.stderr)
        sys.exit(1)

    provider   = (inputs.get("provider")   or "anthropic").lower()
    search_api = (inputs.get("search_api") or "nexar").lower()

    # @local:part_search_se variant always uses siliconexpert
    # Detect via the function name embedded in the manifest run_command if needed;
    # here we rely on the input parameter.
    if search_api not in ("nexar", "siliconexpert"):
        print(f"ERROR: unknown search_api '{search_api}' — must be nexar or siliconexpert",
              file=sys.stderr)
        sys.exit(1)

    model_name = inputs.get("model") or PROVIDER_DEFAULTS.get(provider, "gpt-4o")
    api_key    = _resolve_api_key(inputs, provider)

    if not api_key:
        env_name = {"anthropic": "ANTHROPIC_API_KEY",
                    "openai":    "OPENAI_API_KEY",
                    "genesis":   "GENESIS_API_KEY"}.get(provider, "API_KEY")
        print(f"ERROR: no API key found. Supply llm_api_key auth_info or set {env_name}",
              file=sys.stderr)
        sys.exit(1)

    # ── Set up output directory ───────────────────────────────────────────────
    if args.temp_dir:
        out_dir = Path(args.temp_dir) / "out"
    else:
        out_dir = Path(tempfile.mkdtemp()) / "out"
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── Optional: Istari client for linking outputs ───────────────────────────
    istari = _build_istari_capability()

    # ── Build agents ──────────────────────────────────────────────────────────
    print("Part Search Agent (Istari Module)")
    print("=" * 60)
    print(f"  Provider:    {provider}")
    print(f"  LLM model:   {model_name}")
    print(f"  Search API:  {search_api}")
    print(f"  Istari link: {'enabled' if istari else 'disabled (no credentials in env)'}")

    schema_text   = load_schema(search_api)
    extract_agent, transform_agent = build_agents(provider, api_key, model_name,
                                                  schema_text, search_api)

    # ── Run pipeline ──────────────────────────────────────────────────────────
    result = run_pipeline(
        requirements_path=requirements_path,
        output_dir=out_dir,
        istari=istari,
        extract_agent=extract_agent,
        transform_agent=transform_agent,
        search_api=search_api,
    )

    # ── Write output file ─────────────────────────────────────────────────────
    Path(args.output_file).write_text(
        json.dumps(result["output_files"], indent=2)
    )

    specs = result["summary"].get("specs_generated", 0)
    skipped = len(result["summary"].get("skipped_ids", []))
    print(f"\nDone. {specs} spec(s) generated, {skipped} requirement(s) skipped.")
    print(f"Output file: {args.output_file}")


if __name__ == "__main__":
    main()
