#!/usr/bin/env bash
# Build a self-contained PyInstaller binary for distribution.
# Run from the module root directory.
# Output: dist/part_search_handler (Linux/macOS) or dist/part_search_handler.exe (Windows)
set -euo pipefail

echo "Installing dependencies..."
pip install -r requirements.txt
pip install pyinstaller

echo "Building binary..."
pyinstaller \
  --onefile \
  --name part_search_handler \
  --add-data "part-search-spec.schema.json:." \
  --add-data "se-part-search-spec.schema.json:." \
  part_search_handler.py

echo "Done. Binary: dist/part_search_handler"
echo ""
echo "After building, update module_manifest.json:"
echo "  entrypoint:  dist/part_search_handler"
echo "  run_command: {entrypoint} --input-file {input_file} --output-file {output_file} --temp-dir {temp_dir}"
echo ""
echo "Then compute the module checksum:"
echo "  sha256sum dist/part_search_handler"
echo "  (update module_checksum in module_manifest.json)"
